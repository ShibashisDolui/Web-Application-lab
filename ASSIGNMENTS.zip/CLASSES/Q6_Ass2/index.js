var firstTimeGetState = 0, firstTimeGetDist = 0;

document.getElementById("states").addEventListener('click', function(){
	if(firstTimeGetState) return;

	firstTimeGetState = 1;
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function(){
		if(this.readyState === 4 && this.status === 200){
			// success and response is received
			const states = this.responseText.split("$");
			
			firstTimeGetDist = 0;
			let options = "<option>select</option>";
			for(let i = 0; i < states.length; i++)
				options = `${options}<option>${states[i]}</option>`;

			document.getElementById('states').innerHTML = options;
		}
	}
	xhttp.open("POST", "index.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send();
});

document.getElementById("districts").addEventListener('click', function(){
	if(firstTimeGetDist) return;

	firstTimeGetDist = 1;
	var state = document.getElementById("states").value;
	if(!state){
		alert('First select a state!');
		return;
	}

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function(){
		if(this.readyState === 4 && this.status === 200){
			// success and response is received
			const dists = this.responseText.split("$");
			// console.log(states);
			let options = "<option>select</option>";
			for(let i = 0; i < dists.length; i++)
				options = `${options}<option>${dists[i]}</option>`;

			document.getElementById('districts').innerHTML = options;
		}
	}
	xhttp.open("POST", "getAllDists.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send('state=' + state);
});

document.getElementById("districts").addEventListener('change', function(){
	var state = document.getElementById("states").value;
	if(!state){
		alert('First select a state!');
		return;
	}
	var dist = document.getElementById("districts").value;
	if(!dist){
		alert('First select a district!');
		return;
	}
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function(){
		if(this.readyState === 4 && this.status === 200){
			// success and response is received
			document.getElementById('info').innerHTML = this.responseText;
		}
	}
	xhttp.open("POST", "getInfo.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send('state=' + state + "&dist=" + dist);
});
