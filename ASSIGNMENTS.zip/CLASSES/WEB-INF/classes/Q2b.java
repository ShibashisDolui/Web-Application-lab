import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Q2b extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","Shibashis@99");
			Statement stmt = con.createStatement();
			String dname = request.getParameter("dept");
			String query = "select * from students where dept = \"" + dname + "\"";
			stmt.executeQuery(query);
			ResultSet rs = stmt.getResultSet();
			response.setContentType("text/html");
			ResultSetMetaData md = rs.getMetaData();
			PrintWriter out = response.getWriter();
			out.println("<html><body>"); 
			out.println("<table border=\"1\"><tr>"); 
			for (int i = 1; i <= md.getColumnCount(); i++) { 
			  out.print("<th>" + md.getColumnName(i) + "</th>"); 
			} 
			out.println("</tr>");
			while (rs.next()) { 
			  out.println("<tr>");
			  for (int i = 1; i <= md.getColumnCount(); i++) { 
			     out.print("<td>" + rs.getString(i) + "</td>"); 
			  } 
			  out.println("</tr>"); 
			} 
			out.println("</table>");
			out.println("</body></html>");
			rs.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
