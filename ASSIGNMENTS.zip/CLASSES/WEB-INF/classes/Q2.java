import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Q2 extends HttpServlet{
    public void doPost(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","Shibashis@99");
			Statement stmt = con.createStatement();
			String inputText = request.getParameter("string");
			String query = "select * from students where name REGEXP \"" + inputText + "\";";
			stmt.executeQuery(query);
			ResultSet rs = stmt.getResultSet();
			ResultSetMetaData md = rs.getMetaData();
			out.println("<html><body>"); 
			out.println("<table border=\"1\"><tr>"); 
			for (int i = 1; i <= md.getColumnCount(); i++) { 
			  out.print("<th>" + md.getColumnName(i) + "</th>"); 
			} 
			out.println("</tr>");
			while (rs.next()) { 
			  out.println("<tr>");
			  for (int i = 1; i <= md.getColumnCount(); i++) { 
			     out.print("<td>" + rs.getString(i) + "</td>"); 
			  } 
			  out.println("</tr>"); 
			} 
			out.println("</table>");
			out.println("</body></html>");
			rs.close();
		}
		catch(Exception e) {
			out.println(e);
		}
        out.close();
    }
}