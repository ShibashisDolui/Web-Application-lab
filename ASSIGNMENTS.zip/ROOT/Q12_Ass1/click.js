function clicked(){
    document.querySelector("#mydiv").innerHTML="<img src=\"img.jpg\"/>"
}
